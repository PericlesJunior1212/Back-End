<?php
namespace App\Models;

class Barbeiro extends User
{
    use HasFactory;

    protected $table = 'barbeiros';
 
    public $timestamps = false;

    protected $primaryKey = 'id_barbeiro';

    protected $guarded = ["id_barbeiro"];

    protected $fillable = [
        "id_user", //foreign key
        "id_banco", //foreign key
        "chave_pix",
        "numero_agencia",
        "numero_conta"
    ];

    public function barbeiro()
    {
        return $this->belongTo(User::class, 'id_user', 'id');
    }

    public function agendamento()
    {
        return $this->hasMany(Agendamento::class, 'id_barbeiro', 'id_barbeiro');
    }

    public function gruposMenus() : BelongsToMany
    {
        return $this->belongsToMany(GrupoMenu::class);
    }
}
