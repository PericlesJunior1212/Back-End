<?php

namespace App\Models;



class Cliente extends user
{
    use HasFactory;

    protected $table = 'clientes';
 
    public $timestamps = false;

    protected $primaryKey = 'id_cliente';

    protected $guarded = ["id_cliente"];

    protected $fillable = [
        "nome_grupo"
    ];

    public function nome_grupo()
    {
        return $this->nome_grupo;
    }

    public function usuario()
    {
        return $this->hasMany(User::class, 'id_grupo', 'id_grupo');
    }

    public function gruposMenus() : BelongsToMany
    {
        return $this->belongsToMany(GrupoMenu::class);
    }
}
